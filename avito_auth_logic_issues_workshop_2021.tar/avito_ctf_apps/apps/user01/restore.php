<?php

//error_reporting(0); 

session_start();


if( isset($_SESSION['is_auth'])) {

	$_SESSION = array();		

	session_regenerate_id();

	header("Location: /restore"); 

	exit();

};


if($_POST)
{	
	
	if( isset($_POST['phone']) and isset($_POST['send_sms']) )
	{	
		
		if(preg_match("/^\+7[0-9]{10}$/", $_POST['phone']) and strlen($_POST['phone'])>9 ) {


			$conn = pg_connect("host=db dbname=pt_db user=pt_user password=jw8s0F4");

			$phone = pg_escape_literal($_POST['phone']) ;

			$query = "SELECT name,phone,password,info,data,is_admin FROM pt.user00_tbl WHERE phone = $phone ; ";

			$result = pg_query($conn, $query);
			$row = pg_fetch_row($result);

			if(!$row){

				$message = 'Телефон не найден';
				unset($_SESSION['check_code']);

			} else {

				$user = array(  'name' => $row[0],
						'phone' => $row[1],
						'password' => $row[2],
						'info' => $row[3],
						'data' => $row[4],
						'is_admin' => $row[5]);

				if( trim($user['is_admin']) !== 't' ) {

					unset($_SESSION['send_sms']);

					$_SESSION['check_code'] = 1 ;
					$_SESSION['name'] = $user['name'];
					$_SESSION['phone'] = $user['phone'];
					$_SESSION['info'] = $user['info'];
					$_SESSION['date'] = $user['data'];

					$_SESSION['sms'] = '10'.rand(10,99) ;

					if(trim($user['phone']) == trim("+79260000032") or trim($user['phone']) == trim("+79260000075") ) {
						$skip=1;

					} else {
						$message = send("gate.iqsms.ru", 80, "z1620377373817", "906114", trim($user['phone'],'+'), $_SESSION['sms']);
					};

					
				} else {

					$message = 'Админ не может восстановить пароль по смс';
					unset($_SESSION['check_code']);

				};


			};	


		};		

	};


	if(isset($_SESSION['check_code']) and isset($_POST['phone']) and isset($_POST['sms']) and !isset($_POST['pwd']))
	{	

		if(isset($_SESSION['check_code']) and ($_POST['sms'] === $_SESSION['sms'] or $_POST['sms'] === '9876') ) {


			session_regenerate_id();

			unset($_SESSION['check_code']);
			$_SESSION['set_pass'] = 1 ;

		
		} else {

			$message = 'Неверный код СМС';

		};

	};

	if(isset($_SESSION['set_pass']) and isset($_POST['phone']) and isset($_POST['pwd']) and !isset($_POST['sms']) )
	{	

		if( preg_match("/^\+7[0-9]{10}$/", $_POST['phone']) and strlen($_POST['phone'])>9 and strlen($_POST['pwd'])>5 ) {

			$conn = pg_connect("host=db dbname=pt_db user=pt_user password=jw8s0F4");
			
			$phone = pg_escape_literal($_POST['phone']) ;
			$pwd = pg_escape_literal($_POST['pwd']) ;


			$query = "UPDATE pt.user00_tbl SET password = $pwd WHERE phone = $phone ;";

			$result = pg_query($conn, $query);

			if( $result ) {

				session_regenerate_id();

				unset($_SESSION['set_pass']);

				$_SESSION['is_auth'] = 1; 

				header("Location: /"); 

				exit();
				
			} else {

				$message = 'Не удалось обновить пароль';

			};



		} else {
				
			$message = 'Некорректный формат данных';		

		};		


	};


};

function send($host, $port, $login, $password, $phone, $text, $sender = false, $wapurl = false )
{
	$fp = fsockopen($host, $port, $errno, $errstr);
	if (!$fp) {
		return "errno: $errno \nerrstr: $errstr\n";
	}
	fwrite($fp, "GET /send/" .
		"?phone=" . rawurlencode($phone) .
		"&text=" . rawurlencode($text) .
		($sender ? "&sender=" . rawurlencode($sender) : "") .
		($wapurl ? "&wapurl=" . rawurlencode($wapurl) : "") .
		" HTTP/1.0\n");
	fwrite($fp, "Host: " . $host . "\r\n");
	if ($login != "") {
		fwrite($fp, "Authorization: Basic " . 
			base64_encode($login. ":" . $password) . "\n");
	}
	fwrite($fp, "\n");
	$response = "";
	while(!feof($fp)) {
		$response .= fread($fp, 1);
	}
	fclose($fp);
	list($other, $responseBody) = explode("\r\n\r\n", $response, 2);
	return $responseBody;
}

 
?>
 <!DOCTYPE html>
<html lang="en">
<head>
  <title>Avito - Восстановить пароль</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <style>
      .navbar {
        border-bottom: 1px solid #E5E9EF;
      }
      .nav-title {
	font-size: 22px;
      }

      .nav-logo {
	padding-bottom: 6px;
      }

    

	html {
	  position: relative;
	  min-height: 100%;
	}
	body {
	  margin-bottom: 60px;
	}
	.footer {
	  border-top: 1px solid #E5E9EF;
	  position: absolute;
	  bottom: 0;
	  width: 100%;
	  height: 60px; 
	  line-height: 60px;
	}
	.container {
	  max-width: 680px;
	}

	.form-signin {
	  width: 100%;
	  max-width: 330px;
	  padding: 15px;
	  margin: 0 auto;
	}
	.form-signin .checkbox {
	  font-weight: 400;
	}
	.form-signin .form-control {
	  position: relative;
	  box-sizing: border-box;
	  height: auto;
	  padding: 10px;
	  font-size: 16px;
	}
	.form-signin .form-control:focus {
	  z-index: 2;
	}
	.form-signin input[type="email"] {
	  margin-bottom: -1px;
	  border-bottom-right-radius: 0;
	  border-bottom-left-radius: 0;
	}
	.form-signin input[type="password"] {
	  margin-bottom: 10px;
	  border-top-left-radius: 0;
	  border-top-right-radius: 0;
	}

  </style>

</head>



<body >

<nav class="navbar navbar-expand-lg navbar-light" >
          <div class="container">
		<a href="#" class="navbar-brand text-muted">
<svg  class='nav-logo' width="30" height="31" viewBox="0 0 30 31" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="nonzero"><ellipse fill="#97CF26" cx="21.018" cy="22.188" rx="8.018" ry="8.188"></ellipse><ellipse fill="#A169F7" cx="5.732" cy="22.811" rx="3.732" ry="3.811"></ellipse><ellipse fill="#FF6163" cx="21.161" cy="7.27" rx="5.161" ry="5.27"></ellipse><ellipse fill="#0AF" cx="6.589" cy="6.729" rx="6.589" ry="6.729"></ellipse></g></svg>

<svg class='nav-logo' width="69" height="31" viewBox="0 0 69 31" xmlns="http://www.w3.org/2000/svg"><path d="M14.524 26.214l-7.48-7.316h4.847l-2.422-6.74-2.425 6.74 7.48 7.317-1.472-4.09H5.885l-1.473 4.09H.25L7.96 4.78h3.017l7.71 21.434h-4.163zm14.48-14.632h3.909l-5.265 14.632h-4.95l-5.264-14.632h3.91l3.83 10.647 3.83-10.648zm5.545 0h3.91v14.632h-3.91V11.582zm1.968-1.662C35.128 9.92 34 8.77 34 7.35s1.127-2.572 2.518-2.572c1.39 0 2.518 1.15 2.518 2.57S37.908 9.92 36.518 9.92zm15.75 4.886h-4.685v6.05c0 1.638 1.334 2.148 2.494 2.148.946 0 1.716-.235 1.716-.235l.475 3.16s-1.375.587-2.943.587c-4.06 0-5.65-2.168-5.65-5.415v-6.296h-3.093v-3.224h3.093V7.545h3.908v4.037h4.685v3.224zm1.292 4.068c0-4.232 3.437-7.666 7.675-7.666 4.237 0 7.674 3.434 7.674 7.666 0 4.234-3.438 7.666-7.675 7.666-4.238 0-7.675-3.432-7.675-7.666zm3.73.053c0 2.177 1.765 3.943 3.946 3.943 2.18 0 3.946-1.765 3.946-3.942 0-2.176-1.766-3.942-3.947-3.942-2.18 0-3.946 1.766-3.946 3.94z" fill="#000" fill-rule="nonzero"></path></svg>
		</a>

		<div class="collapse navbar-collapse" id="globalNavbar">
              
 			      <ul class="navbar-nav mr-auto order-1">
					<li class="nav-item"><a class="nav-link" href="#">Авто</a></li>
				  	<li class="nav-item"><a class="nav-link" href="#">Недвижимость</a></li>
					<li class="nav-item"><a class="nav-link" href="#">Работа</a></li>
					<li class="nav-item"><a class="nav-link" href="#">Еще...</a></li>
			      </ul>
			      <ul class="navbar-nav d-none d-lg-flex ml-2 order-3">
				                    
				  <li class="nav-item"><a class="nav-link" href="/login">Login</a></li>
				</ul>

                 </div>


          </div>
</nav>

<div class="container">

<br>
<br>

<?if( isset($_SESSION['check_code']) and isset($_POST['phone']) and ( isset($_POST['sms']) or isset($_POST['send_sms'])) ):?>

<div class='text-center' >
<form class="form-signin" method="POST">
<br>
<br>
<h3 class="h3 mb-3 font-weight-normal">Восстановить пароль:</h3>
<hr>

<label for="inputEmail" class="sr-only">Телефон</label>
<input type="text" id="inputPhone" class="form-control" placeholder="+79260000XXX" autofocus name="phone" value="<?=$_POST['phone']?>" readonly>
<br>
<label for="inputPassword" class="sr-only">Код</label>
<input type="text" id="inputPassword" class="form-control" placeholder="0000" name="sms">
<div class="checkbox mb-3">
<p class="text-success text-center"></p>

</div>
<button class="btn btn-lg btn-primary btn-block" type="submit">Подтвердить</button>
</form>

<label for="inputPassword" class="col-sm-10 col-form-label text-danger"><?=$message?></label>

</div>

<?elseif( isset($_SESSION['set_pass']) and isset($_POST['phone']) and isset($_POST['sms']) ):?>

<div class='text-center' >
<form class="form-signin" method="POST">
<br>
<br>
<h3 class="h3 mb-3 font-weight-normal">Восстановить пароль:</h3>
<hr>

<label for="inputEmail" class="sr-only">Телефон</label>
<input type="text" id="inputPhone" class="form-control" placeholder="+79260000XXX" autofocus name="phone" value="<?=$_POST['phone']?>" readonly>
<br>
<label for="inputPassword" class="sr-only">Пароль</label>
<input type="password" id="inputPassword" class="form-control" placeholder="Пароль" name="pwd">
<div class="checkbox mb-3">
<p class="text-success text-center"></p>

</div>
<button class="btn btn-lg btn-primary btn-block" type="submit">Восстановить</button>
</form>

<label for="inputPassword" class="col-sm-10 col-form-label text-danger"><?=$message?></label>

</div>

<?else:?>

<div class='text-center' >
<form class="form-signin" method="POST">
<br>
<br>
<h3 class="h3 mb-3 font-weight-normal">Восстановить пароль:</h3>
<hr>

<label for="inputEmail" class="sr-only">Телефон</label>
<input type="text" id="inputPhone" class="form-control" placeholder="+79260000XXX" autofocus name="phone" value="<?=$_POST['phone']?>">
<input id="send_sms" name="send_sms" type="hidden" value="1">
<br>
<div class="checkbox mb-3">
<p class="text-success text-center">Вы получите SMS c кодом на указанный номер телефона</p>

</div>
<button class="btn btn-lg btn-primary btn-block" type="submit">Получить СМС</button>
</form>

<label for="inputPassword" class="col-sm-10 col-form-label text-danger"><?=$message?></label>


</div>




<?endif;?>

<br>

</div>

<footer class="footer">
	<div class="container">
	<span class="text-muted">Авито — сайт объявлений России.</span>
	</div>
</footer>

</body>
</html>


