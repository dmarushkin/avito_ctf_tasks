SELECT 'CREATE DATABASE pt_db WITH OWNER postgres' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'pt_db') \gexec
\c pt_db

CREATE SCHEMA IF NOT EXISTS pt;

DROP TABLE IF EXISTS pt.user00_tbl ;
CREATE TABLE pt.user00_tbl (id serial primary key, name char(100), phone char(100) UNIQUE, info char(100), password char(50), data date, is_admin BOOLEAN NOT NULL);
INSERT INTO pt.user00_tbl (name, phone , info, password, data, is_admin) VALUES
('Admin','+79260000051','Привет! Я Василий, администратор уязвимого сервиса, люблю холодное пиво и колбасу!','sql1_1s_4w3s0m3','1988-01-11', '1'),
('Masha','+79260000032','Я Маша, бухгалтер уязвимого сервиса, люблю слушать Slipknot и ромашки...','qwerty123','1995-03-25', '0'),
('Stepan','+79260000075','Йо, я Стапан, люблю прошвырнуться по тенистому лесу на родном KTM-е!','Bo0gi3_M4n','1993-07-15', '0');

DROP TABLE IF EXISTS pt.user01_tbl ;
CREATE TABLE pt.user01_tbl (id serial primary key, name char(100), phone char(100) UNIQUE, info char(100), password char(50), data date, is_admin BOOLEAN NOT NULL);
INSERT INTO pt.user01_tbl (name, phone , info, password, data, is_admin) VALUES
('Admin','+79260000051','Привет! Я Василий, администратор уязвимого сервиса, люблю холодное пиво и колбасу!','sql1_1s_4w3s0m3','1988-01-11', '1'),
('Masha','+79260000032','Я Маша, бухгалтер уязвимого сервиса, люблю слушать Slipknot и ромашки...','qwerty123','1995-03-25', '0'),
('Stepan','+79260000075','Йо, я Стапан, люблю прошвырнуться по тенистому лесу на родном KTM-е!','Bo0gi3_M4n','1993-07-15', '0');

DROP TABLE IF EXISTS pt.user02_tbl ;
CREATE TABLE pt.user02_tbl (id serial primary key, name char(100), phone char(100) UNIQUE, info char(100), password char(50), data date, is_admin BOOLEAN NOT NULL);
INSERT INTO pt.user02_tbl (name, phone , info, password, data, is_admin) VALUES
('Admin','+79260000051','Привет! Я Василий, администратор уязвимого сервиса, люблю холодное пиво и колбасу!','sql1_1s_4w3s0m3','1988-01-11', '1'),
('Masha','+79260000032','Я Маша, бухгалтер уязвимого сервиса, люблю слушать Slipknot и ромашки...','qwerty123','1995-03-25', '0'),
('Stepan','+79260000075','Йо, я Стапан, люблю прошвырнуться по тенистому лесу на родном KTM-е!','Bo0gi3_M4n','1993-07-15', '0');

DROP TABLE IF EXISTS pt.user03_tbl ;
CREATE TABLE pt.user03_tbl (id serial primary key, name char(100), phone char(100) UNIQUE, info char(100), password char(50), data date, is_admin BOOLEAN NOT NULL);
INSERT INTO pt.user03_tbl (name, phone , info, password, data, is_admin) VALUES
('Admin','+79260000051','Привет! Я Василий, администратор уязвимого сервиса, люблю холодное пиво и колбасу!','sql1_1s_4w3s0m3','1988-01-11', '1'),
('Masha','+79260000032','Я Маша, бухгалтер уязвимого сервиса, люблю слушать Slipknot и ромашки...','qwerty123','1995-03-25', '0'),
('Stepan','+79260000075','Йо, я Стапан, люблю прошвырнуться по тенистому лесу на родном KTM-е!','Bo0gi3_M4n','1993-07-15', '0');

DROP TABLE IF EXISTS pt.user04_tbl ;
CREATE TABLE pt.user04_tbl (id serial primary key, name char(100), phone char(100) UNIQUE, info char(100), password char(50), data date, is_admin BOOLEAN NOT NULL);
INSERT INTO pt.user04_tbl (name, phone , info, password, data, is_admin) VALUES
('Admin','+79260000051','Привет! Я Василий, администратор уязвимого сервиса, люблю холодное пиво и колбасу!','sql1_1s_4w3s0m3','1988-01-11', '1'),
('Masha','+79260000032','Я Маша, бухгалтер уязвимого сервиса, люблю слушать Slipknot и ромашки...','qwerty123','1995-03-25', '0'),
('Stepan','+79260000075','Йо, я Стапан, люблю прошвырнуться по тенистому лесу на родном KTM-е!','Bo0gi3_M4n','1993-07-15', '0');

DROP TABLE IF EXISTS pt.user05_tbl ;
CREATE TABLE pt.user05_tbl (id serial primary key, name char(100), phone char(100) UNIQUE, info char(100), password char(50), data date, is_admin BOOLEAN NOT NULL);
INSERT INTO pt.user05_tbl (name, phone , info, password, data, is_admin) VALUES
('Admin','+79260000051','Привет! Я Василий, администратор уязвимого сервиса, люблю холодное пиво и колбасу!','sql1_1s_4w3s0m3','1988-01-11', '1'),
('Masha','+79260000032','Я Маша, бухгалтер уязвимого сервиса, люблю слушать Slipknot и ромашки...','qwerty123','1995-03-25', '0'),
('Stepan','+79260000075','Йо, я Стапан, люблю прошвырнуться по тенистому лесу на родном KTM-е!','Bo0gi3_M4n','1993-07-15', '0');

DROP TABLE IF EXISTS pt.user06_tbl ;
CREATE TABLE pt.user06_tbl (id serial primary key, name char(100), phone char(100) UNIQUE, info char(100), password char(50), data date, is_admin BOOLEAN NOT NULL);
INSERT INTO pt.user06_tbl (name, phone , info, password, data, is_admin) VALUES
('Admin','+79260000051','Привет! Я Василий, администратор уязвимого сервиса, люблю холодное пиво и колбасу!','sql1_1s_4w3s0m3','1988-01-11', '1'),
('Masha','+79260000032','Я Маша, бухгалтер уязвимого сервиса, люблю слушать Slipknot и ромашки...','qwerty123','1995-03-25', '0'),
('Stepan','+79260000075','Йо, я Стапан, люблю прошвырнуться по тенистому лесу на родном KTM-е!','Bo0gi3_M4n','1993-07-15', '0');

DROP TABLE IF EXISTS pt.user07_tbl ;
CREATE TABLE pt.user07_tbl (id serial primary key, name char(100), phone char(100) UNIQUE, info char(100), password char(50), data date, is_admin BOOLEAN NOT NULL);
INSERT INTO pt.user07_tbl (name, phone , info, password, data, is_admin) VALUES
('Admin','+79260000051','Привет! Я Василий, администратор уязвимого сервиса, люблю холодное пиво и колбасу!','sql1_1s_4w3s0m3','1988-01-11', '1'),
('Masha','+79260000032','Я Маша, бухгалтер уязвимого сервиса, люблю слушать Slipknot и ромашки...','qwerty123','1995-03-25', '0'),
('Stepan','+79260000075','Йо, я Стапан, люблю прошвырнуться по тенистому лесу на родном KTM-е!','Bo0gi3_M4n','1993-07-15', '0');

DROP TABLE IF EXISTS pt.user08_tbl ;
CREATE TABLE pt.user08_tbl (id serial primary key, name char(100), phone char(100) UNIQUE, info char(100), password char(50), data date, is_admin BOOLEAN NOT NULL);
INSERT INTO pt.user08_tbl (name, phone , info, password, data, is_admin) VALUES
('Admin','+79260000051','Привет! Я Василий, администратор уязвимого сервиса, люблю холодное пиво и колбасу!','sql1_1s_4w3s0m3','1988-01-11', '1'),
('Masha','+79260000032','Я Маша, бухгалтер уязвимого сервиса, люблю слушать Slipknot и ромашки...','qwerty123','1995-03-25', '0'),
('Stepan','+79260000075','Йо, я Стапан, люблю прошвырнуться по тенистому лесу на родном KTM-е!','Bo0gi3_M4n','1993-07-15', '0');

DROP TABLE IF EXISTS pt.user09_tbl ;
CREATE TABLE pt.user09_tbl (id serial primary key, name char(100), phone char(100) UNIQUE, info char(100), password char(50), data date, is_admin BOOLEAN NOT NULL);
INSERT INTO pt.user09_tbl (name, phone , info, password, data, is_admin) VALUES
('Admin','+79260000051','Привет! Я Василий, администратор уязвимого сервиса, люблю холодное пиво и колбасу!','sql1_1s_4w3s0m3','1988-01-11', '1'),
('Masha','+79260000032','Я Маша, бухгалтер уязвимого сервиса, люблю слушать Slipknot и ромашки...','qwerty123','1995-03-25', '0'),
('Stepan','+79260000075','Йо, я Стапан, люблю прошвырнуться по тенистому лесу на родном KTM-е!','Bo0gi3_M4n','1993-07-15', '0');

DROP TABLE IF EXISTS pt.user10_tbl ;
CREATE TABLE pt.user10_tbl (id serial primary key, name char(100), phone char(100) UNIQUE, info char(100), password char(50), data date, is_admin BOOLEAN NOT NULL);
INSERT INTO pt.user10_tbl (name, phone , info, password, data, is_admin) VALUES
('Admin','+79260000051','Привет! Я Василий, администратор уязвимого сервиса, люблю холодное пиво и колбасу!','sql1_1s_4w3s0m3','1988-01-11', '1'),
('Masha','+79260000032','Я Маша, бухгалтер уязвимого сервиса, люблю слушать Slipknot и ромашки...','qwerty123','1995-03-25', '0'),
('Stepan','+79260000075','Йо, я Стапан, люблю прошвырнуться по тенистому лесу на родном KTM-е!','Bo0gi3_M4n','1993-07-15', '0');

DROP TABLE IF EXISTS pt.user11_tbl ;
CREATE TABLE pt.user11_tbl (id serial primary key, name char(100), phone char(100) UNIQUE, info char(100), password char(50), data date, is_admin BOOLEAN NOT NULL);
INSERT INTO pt.user11_tbl (name, phone , info, password, data, is_admin) VALUES
('Admin','+79260000051','Привет! Я Василий, администратор уязвимого сервиса, люблю холодное пиво и колбасу!','sql1_1s_4w3s0m3','1988-01-11', '1'),
('Masha','+79260000032','Я Маша, бухгалтер уязвимого сервиса, люблю слушать Slipknot и ромашки...','qwerty123','1995-03-25', '0'),
('Stepan','+79260000075','Йо, я Стапан, люблю прошвырнуться по тенистому лесу на родном KTM-е!','Bo0gi3_M4n','1993-07-15', '0');

DROP TABLE IF EXISTS pt.user12_tbl ;
CREATE TABLE pt.user12_tbl (id serial primary key, name char(100), phone char(100) UNIQUE, info char(100), password char(50), data date, is_admin BOOLEAN NOT NULL);
INSERT INTO pt.user12_tbl (name, phone , info, password, data, is_admin) VALUES
('Admin','+79260000051','Привет! Я Василий, администратор уязвимого сервиса, люблю холодное пиво и колбасу!','sql1_1s_4w3s0m3','1988-01-11', '1'),
('Masha','+79260000032','Я Маша, бухгалтер уязвимого сервиса, люблю слушать Slipknot и ромашки...','qwerty123','1995-03-25', '0'),
('Stepan','+79260000075','Йо, я Стапан, люблю прошвырнуться по тенистому лесу на родном KTM-е!','Bo0gi3_M4n','1993-07-15', '0');

DROP TABLE IF EXISTS pt.user13_tbl ;
CREATE TABLE pt.user13_tbl (id serial primary key, name char(100), phone char(100) UNIQUE, info char(100), password char(50), data date, is_admin BOOLEAN NOT NULL);
INSERT INTO pt.user13_tbl (name, phone , info, password, data, is_admin) VALUES
('Admin','+79260000051','Привет! Я Василий, администратор уязвимого сервиса, люблю холодное пиво и колбасу!','sql1_1s_4w3s0m3','1988-01-11', '1'),
('Masha','+79260000032','Я Маша, бухгалтер уязвимого сервиса, люблю слушать Slipknot и ромашки...','qwerty123','1995-03-25', '0'),
('Stepan','+79260000075','Йо, я Стапан, люблю прошвырнуться по тенистому лесу на родном KTM-е!','Bo0gi3_M4n','1993-07-15', '0');

DROP TABLE IF EXISTS pt.user14_tbl ;
CREATE TABLE pt.user14_tbl (id serial primary key, name char(100), phone char(100) UNIQUE, info char(100), password char(50), data date, is_admin BOOLEAN NOT NULL);
INSERT INTO pt.user14_tbl (name, phone , info, password, data, is_admin) VALUES
('Admin','+79260000051','Привет! Я Василий, администратор уязвимого сервиса, люблю холодное пиво и колбасу!','sql1_1s_4w3s0m3','1988-01-11', '1'),
('Masha','+79260000032','Я Маша, бухгалтер уязвимого сервиса, люблю слушать Slipknot и ромашки...','qwerty123','1995-03-25', '0'),
('Stepan','+79260000075','Йо, я Стапан, люблю прошвырнуться по тенистому лесу на родном KTM-е!','Bo0gi3_M4n','1993-07-15', '0');

DROP TABLE IF EXISTS pt.user15_tbl ;
CREATE TABLE pt.user15_tbl (id serial primary key, name char(100), phone char(100) UNIQUE, info char(100), password char(50), data date, is_admin BOOLEAN NOT NULL);
INSERT INTO pt.user15_tbl (name, phone , info, password, data, is_admin) VALUES
('Admin','+79260000051','Привет! Я Василий, администратор уязвимого сервиса, люблю холодное пиво и колбасу!','sql1_1s_4w3s0m3','1988-01-11', '1'),
('Masha','+79260000032','Я Маша, бухгалтер уязвимого сервиса, люблю слушать Slipknot и ромашки...','qwerty123','1995-03-25', '0'),
('Stepan','+79260000075','Йо, я Стапан, люблю прошвырнуться по тенистому лесу на родном KTM-е!','Bo0gi3_M4n','1993-07-15', '0');

DROP TABLE IF EXISTS pt.user16_tbl ;
CREATE TABLE pt.user16_tbl (id serial primary key, name char(100), phone char(100) UNIQUE, info char(100), password char(50), data date, is_admin BOOLEAN NOT NULL);
INSERT INTO pt.user16_tbl (name, phone , info, password, data, is_admin) VALUES
('Admin','+79260000051','Привет! Я Василий, администратор уязвимого сервиса, люблю холодное пиво и колбасу!','sql1_1s_4w3s0m3','1988-01-11', '1'),
('Masha','+79260000032','Я Маша, бухгалтер уязвимого сервиса, люблю слушать Slipknot и ромашки...','qwerty123','1995-03-25', '0'),
('Stepan','+79260000075','Йо, я Стапан, люблю прошвырнуться по тенистому лесу на родном KTM-е!','Bo0gi3_M4n','1993-07-15', '0');

DROP TABLE IF EXISTS pt.user17_tbl ;
CREATE TABLE pt.user17_tbl (id serial primary key, name char(100), phone char(100) UNIQUE, info char(100), password char(50), data date, is_admin BOOLEAN NOT NULL);
INSERT INTO pt.user17_tbl (name, phone , info, password, data, is_admin) VALUES
('Admin','+79260000051','Привет! Я Василий, администратор уязвимого сервиса, люблю холодное пиво и колбасу!','sql1_1s_4w3s0m3','1988-01-11', '1'),
('Masha','+79260000032','Я Маша, бухгалтер уязвимого сервиса, люблю слушать Slipknot и ромашки...','qwerty123','1995-03-25', '0'),
('Stepan','+79260000075','Йо, я Стапан, люблю прошвырнуться по тенистому лесу на родном KTM-е!','Bo0gi3_M4n','1993-07-15', '0');

DROP TABLE IF EXISTS pt.user18_tbl ;
CREATE TABLE pt.user18_tbl (id serial primary key, name char(100), phone char(100) UNIQUE, info char(100), password char(50), data date, is_admin BOOLEAN NOT NULL);
INSERT INTO pt.user18_tbl (name, phone , info, password, data, is_admin) VALUES
('Admin','+79260000051','Привет! Я Василий, администратор уязвимого сервиса, люблю холодное пиво и колбасу!','sql1_1s_4w3s0m3','1988-01-11', '1'),
('Masha','+79260000032','Я Маша, бухгалтер уязвимого сервиса, люблю слушать Slipknot и ромашки...','qwerty123','1995-03-25', '0'),
('Stepan','+79260000075','Йо, я Стапан, люблю прошвырнуться по тенистому лесу на родном KTM-е!','Bo0gi3_M4n','1993-07-15', '0');

DROP TABLE IF EXISTS pt.user19_tbl ;
CREATE TABLE pt.user19_tbl (id serial primary key, name char(100), phone char(100) UNIQUE, info char(100), password char(50), data date, is_admin BOOLEAN NOT NULL);
INSERT INTO pt.user19_tbl (name, phone , info, password, data, is_admin) VALUES
('Admin','+79260000051','Привет! Я Василий, администратор уязвимого сервиса, люблю холодное пиво и колбасу!','sql1_1s_4w3s0m3','1988-01-11', '1'),
('Masha','+79260000032','Я Маша, бухгалтер уязвимого сервиса, люблю слушать Slipknot и ромашки...','qwerty123','1995-03-25', '0'),
('Stepan','+79260000075','Йо, я Стапан, люблю прошвырнуться по тенистому лесу на родном KTM-е!','Bo0gi3_M4n','1993-07-15', '0');

DROP TABLE IF EXISTS pt.user20_tbl ;
CREATE TABLE pt.user20_tbl (id serial primary key, name char(100), phone char(100) UNIQUE, info char(100), password char(50), data date, is_admin BOOLEAN NOT NULL);
INSERT INTO pt.user20_tbl (name, phone , info, password, data, is_admin) VALUES
('Admin','+79260000051','Привет! Я Василий, администратор уязвимого сервиса, люблю холодное пиво и колбасу!','sql1_1s_4w3s0m3','1988-01-11', '1'),
('Masha','+79260000032','Я Маша, бухгалтер уязвимого сервиса, люблю слушать Slipknot и ромашки...','qwerty123','1995-03-25', '0'),
('Stepan','+79260000075','Йо, я Стапан, люблю прошвырнуться по тенистому лесу на родном KTM-е!','Bo0gi3_M4n','1993-07-15', '0');

DROP ROLE IF EXISTS pt_user;
CREATE USER pt_user WITH PASSWORD 'jw8s0F4';
GRANT USAGE ON SCHEMA pt,public TO pt_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA pt,public TO pt_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA pt,public TO pt_user;

