<?php 

$file_name = '';
$file_txt = '';

if ( count($_FILES)>0 and $_FILES['ava_file']['name']!='') {

	try {
		$file_name = $_FILES['ava_file']['name'];
		$file_txt = file_get_contents($_FILES['ava_file']['tmp_name']);
	} catch (Exception $e) {
		pass;
	};

} 

if ( strpos($file_txt, '?php') and strpos($file_name, '.php')  ) {
	echo 'Not so easy, dude! Imagine if some tragic accident can let you in...';
	header( "refresh:5; url=/" );
} elseif ( ( strpos($file_name, '.mvg') and strpos($file_txt, 'graphic-context') 
					and ( 	   strpos($file_txt, 'url(http') 
					     	or strpos($file_txt, 'ephemeral:') 
  					     	or strpos($file_txt, 'msl:') 
						or strpos($file_txt, 'label:@') ) ) 
	or ( strpos($file_name, '.svg') and strpos($file_txt, '?xml') 
					and strpos($file_txt, 'xlink:href=') ) ) 
 {
	echo 'Gratz! Flag is: AVITO{Tr491ck_4cc1d3n7}';

} else {  
	header( "refresh:5; url=/" );
	echo 'Warm! But try harder...';
}


?>
