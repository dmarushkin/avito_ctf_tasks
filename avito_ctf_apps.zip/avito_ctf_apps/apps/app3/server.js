console.log("Server started");
var Msg = '';
var WebSocketServer = require('ws').Server
    , wss = new WebSocketServer({port: 3000});
wss.on('connection', function(ws) {
	
	ws.send(JSON.stringify({"UserID":"b094b216aea9525eda6b6711772ae393","user":"Admin", "message":"Рад тебя видеть! Что стряслось? "}));

        ws.on('message', function(message) {
		
		if (message != "READY") {
			
			try { 
				mess_json = JSON.parse(message);

				if (mess_json["user"] == "User1" && mess_json["UserID"] == "705a29ce9e7b887f6c4f7b05362d35ff") {
					
					console.log('Received from User1: %s', mess_json["message"]);
					ws.send( message);

					rand = Math.floor(Math.random() * Math.floor(6));

					switch(rand) {
					  case 1:  
					    ws.send(JSON.stringify({"UserID":"b094b216aea9525eda6b6711772ae393","user":"Admin", "message":"Ты мой бедный зайчик!"}));
					    break;
					  case 2:  
					    ws.send(JSON.stringify({"UserID":"b094b216aea9525eda6b6711772ae393","user":"Admin", "message":"Иди обниму!"}));
					    break;
					  case 3:  
					    ws.send(JSON.stringify({"UserID":"b094b216aea9525eda6b6711772ae393","user":"Admin", "message":"Как же тебе тяжело!"}));
					    break;
					  case 4:  
					    ws.send(JSON.stringify({"UserID":"b094b216aea9525eda6b6711772ae393","user":"Admin", "message":"Это просто такой день..."}));
					    break;
					  case 5:  
					    ws.send(JSON.stringify({"UserID":"b094b216aea9525eda6b6711772ae393","user":"Admin", "message":"Давай я тебе чаю вкусного заварю!"}));
					    break;
					  default:
					    ws.send(JSON.stringify({"UserID":"b094b216aea9525eda6b6711772ae393","user":"Admin", "message":"Не расстраивайся, всё пройдёт!"}));
					    break;
					}
									
				}

				if (mess_json["user"] == "Admin" && mess_json["UserID"] == "b094b216aea9525eda6b6711772ae393") {
					
					console.log('Received from User1: %s', mess_json["message"]);
					ws.send( message);
					ws.send(JSON.stringify({"UserID":"b094b216aea9525eda6b6711772ae393","user":"Admin", "message":"Давно ты не проверял свой профиль..."}));
						
				}


			}
			catch (e) {
			   console.log('Received error: %s', message);
			}
			


		}


    	});
});
