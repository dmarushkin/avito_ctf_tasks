<?php

error_reporting(0); 

If(isset($_GET))
{
	$conn = pg_connect("host=db dbname=avito_db user=reader password=jw8s0F4");

	if (!$conn) 
	{
	  echo "No connection to db.\n";
	  exit;
	}
	
	if ($_GET['subj'] && $_GET['subj'] !='')
	{
		$subj = ' AND subject like '.pg_escape_literal("%".$_GET['subj']."%");
	}

	if ($_GET['price'] && $_GET['price'] !='')
	{
		$city = ' AND price < '.pg_escape_literal($_GET['price']);
	}

	if ($_GET['city'] && $_GET['city'] !='')
	{
		$city = ' AND city = '.pg_escape_literal($_GET['city']);
	}

	if ($_GET['data'] && $_GET['data'] !='')
	{
		$data = " AND data > '".$_GET['data']."'";
	}

	$query = "SELECT subject,price,city,data,jpg_link FROM avito.data_tbl WHERE 1=1 $data $city $subj $price";

	$result = pg_query($conn, $query);

	if(!$result){echo 'ERROR';}

	while ($row = pg_fetch_row($result)) 
	{
		$out[] = array(
			'jpg_link' => $row[4],
			'subject' => $row[0],
			'price' => $row[1],
			'city' => $row[2],
			'data' => $row[3]); 
	}

	$out_chuncked = array_chunk($out,3,true);

}
 
?>
 <!DOCTYPE html>
<html lang="en">
<head>
  <title>Avito - Поиск объявлений</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <style>
      .navbar {
        border-bottom: 1px solid #E5E9EF;
      }
      .nav-title {
	font-size: 22px;
      }

      .nav-logo {
	padding-bottom: 6px;
      }

    

	html {
	  position: relative;
	  min-height: 100%;
	}
	body {
	  margin-bottom: 60px;
	}
	.footer {
	  border-top: 1px solid #E5E9EF;
	  position: absolute;
	  bottom: 0;
	  width: 100%;
	  height: 60px; 
	  line-height: 60px;
	}
	.container {
	  max-width: 768px;
	}

  </style>

</head>



<body >

<nav class="navbar navbar-expand-lg navbar-light" >
          <div class="container">
		<a href="#" class="navbar-brand text-muted">
<svg  class='nav-logo' width="30" height="31" viewBox="0 0 30 31" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="nonzero"><ellipse fill="#97CF26" cx="21.018" cy="22.188" rx="8.018" ry="8.188"></ellipse><ellipse fill="#A169F7" cx="5.732" cy="22.811" rx="3.732" ry="3.811"></ellipse><ellipse fill="#FF6163" cx="21.161" cy="7.27" rx="5.161" ry="5.27"></ellipse><ellipse fill="#0AF" cx="6.589" cy="6.729" rx="6.589" ry="6.729"></ellipse></g></svg>

<svg class='nav-logo' width="69" height="31" viewBox="0 0 69 31" xmlns="http://www.w3.org/2000/svg"><path d="M14.524 26.214l-7.48-7.316h4.847l-2.422-6.74-2.425 6.74 7.48 7.317-1.472-4.09H5.885l-1.473 4.09H.25L7.96 4.78h3.017l7.71 21.434h-4.163zm14.48-14.632h3.909l-5.265 14.632h-4.95l-5.264-14.632h3.91l3.83 10.647 3.83-10.648zm5.545 0h3.91v14.632h-3.91V11.582zm1.968-1.662C35.128 9.92 34 8.77 34 7.35s1.127-2.572 2.518-2.572c1.39 0 2.518 1.15 2.518 2.57S37.908 9.92 36.518 9.92zm15.75 4.886h-4.685v6.05c0 1.638 1.334 2.148 2.494 2.148.946 0 1.716-.235 1.716-.235l.475 3.16s-1.375.587-2.943.587c-4.06 0-5.65-2.168-5.65-5.415v-6.296h-3.093v-3.224h3.093V7.545h3.908v4.037h4.685v3.224zm1.292 4.068c0-4.232 3.437-7.666 7.675-7.666 4.237 0 7.674 3.434 7.674 7.666 0 4.234-3.438 7.666-7.675 7.666-4.238 0-7.675-3.432-7.675-7.666zm3.73.053c0 2.177 1.765 3.943 3.946 3.943 2.18 0 3.946-1.765 3.946-3.942 0-2.176-1.766-3.942-3.947-3.942-2.18 0-3.946 1.766-3.946 3.94z" fill="#000" fill-rule="nonzero"></path></svg>
		</a>

		<div class="collapse navbar-collapse" id="globalNavbar">
              
 			      <ul class="navbar-nav mr-auto order-1">
					<li class="nav-item"><a class="nav-link" href="#">Авто</a></li>
				  	<li class="nav-item"><a class="nav-link" href="#">Недвижимость</a></li>
					<li class="nav-item"><a class="nav-link" href="#">Работа</a></li>
					<li class="nav-item"><a class="nav-link" href="#">Еще...</a></li>
			      </ul>
			      <ul class="navbar-nav d-none d-lg-flex ml-2 order-3">
				                    
				  <li class="nav-item"><a class="nav-link" href="#">User1</a></li>
				  <li class="nav-item"><a class="nav-link" href="#">Logout</a></li>
				</ul>

                 </div>


          </div>
</nav>

<div class="container">

<br>
<br>
<h4>Поиcк объявлений</h4>
<br>

<form>
  <div class="row">
    <div class="col">
      <input type="text" class="form-control" placeholder="Тема" name="subj" value="<?= $_GET['subj'] ?>">
    </div>
    <div class="col">
      <input type="text" class="form-control" placeholder="цена" name="price" value="<?= $_GET['price'] ?>">
    </div>
    <div class="col">
      <input type="text" class="form-control" placeholder="город" name="city" value="<?= $_GET['city'] ?>">
    </div>
    <div class="col">
      <input type="date" class="form-control" placeholder="data" name="data" value="<?= $_GET['data'] ?>">
    </div>
    <button type="submit" class="btn btn-primary">Найти</button>
  </div>
  
</form>
<br>

<h4>Найдено:</h4>
<br>

<?php foreach($out_chuncked as $chunck): ?>
<div class="row">
	<?php foreach($chunck as $item): ?>
	    <div class="col col-sm-4 ">
	      <img src="jpg/<?= $item['jpg_link']?>" class="img-thumbnail h-75 w-100" style='margin-bottom: 8px;'>
	      <br><a href="#"><b><?= $item['subject']?></b></a>
	      <br><b><?= $item['price']?> p</b>
	      <br><span class='text-muted'><?= $item['city']?>
	       <?= $item['data']?></span>
	    </div>
	<?php endforeach; ?>	
</div>
<br>
<br>
<?php endforeach; ?>

<br>

</div>

<footer class="footer">
	<div class="container">
	<span class="text-muted">Авито — сайт объявлений России.</span>
	</div>
</footer>

</body>
</html>


