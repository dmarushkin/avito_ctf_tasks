SELECT 'CREATE DATABASE avito_db WITH OWNER postgres' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'avito_db') \gexec
\c avito_db
DROP TABLE IF EXISTS avito.data_tbl ;
CREATE SCHEMA IF NOT EXISTS avito;
CREATE TABLE avito.data_tbl (id serial primary key,jpg_link char(100),subject char(100), price char(50), city char(50),data date);
INSERT INTO avito.data_tbl (jpg_link, subject , price, city, data) VALUES
('1.jpg','Продам или отдам кота-сатану','500','Москва','2020-02-05'),
('2.jpg','Котик ждет кошечку для вязки','1500','Уфа','2020-01-12'),
('3.jpg','Продам имераторский трон','20000','Сочи','2020-02-01'),
('4.jpg','Шлепки купальные','1000','Анапа','2019-12-05'),
('5.jpg','Чучело лисы','6000','Москва','2019-11-01'),
('6.jpg','Бутерброд с копченой колбасой','100','Питер','2019-08-05');

CREATE SCHEMA IF NOT EXISTS fl;
DROP TABLE IF EXISTS fl.fl_tbl ;
CREATE TABLE fl.fl_tbl (flag char(100));
INSERT INTO fl.fl_tbl (flag) VALUES
('AVITO{sql1_1s_4w3s0m3}');

DROP ROLE IF EXISTS reader;
CREATE USER reader WITH PASSWORD 'jw8s0F4';
GRANT USAGE ON SCHEMA avito,fl,public TO reader;
GRANT SELECT ON ALL TABLES IN SCHEMA avito,fl,public TO reader;

