import ssl
import requests
import random

from requests.adapters import HTTPAdapter
from requests.packages.urllib3.poolmanager import PoolManager
from requests.packages.urllib3.util import ssl_
from requests.exceptions import ConnectionError
import urllib3
from multiprocessing import Pool

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class TlsAdapter(HTTPAdapter):
    def __init__(self, CIPHERS, ssl_options=0, **kwargs):
        self.ssl_options = ssl_options
        self.ciphers = CIPHERS
        super(TlsAdapter, self).__init__(**kwargs)

    def init_poolmanager(self, *pool_args, **pool_kwargs):
        ctx = ssl_.create_urllib3_context(ciphers=self.ciphers, cert_reqs=ssl.CERT_REQUIRED, options=self.ssl_options)
        self.poolmanager = PoolManager(*pool_args,
                                       ssl_context=ctx,
                                       **pool_kwargs)

ctx = ssl.SSLContext(ssl.PROTOCOL_TLS)
ciphers = list(map(lambda c: c['name'], ctx.get_ciphers()))


def make_req(i):
    item = "{0:0{1}x}".format(i,8)
    CIPHERS = 'ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:' + ':'.join(random.sample(ciphers, 10))

    session = requests.session()
    adapter = TlsAdapter(CIPHERS)
    session.mount("https://", adapter)

    try:
        url = f'https://51.158.161.205/item/{item}'
        r = session.request('GET', url, verify=False)

        if r.status_code != 404:
           print(r.url)
    except Exception as exception:
        print(f'failed {url} {exception} {CIPHERS}')

def main():
    with Pool(100) as p:
        p.map(make_req, range(0, 65536))