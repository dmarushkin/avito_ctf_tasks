from flask import Flask, request, render_template, abort, redirect, url_for, jsonify
import pymongo
import datetime

app = Flask(__name__)

config = {
    "username": "root",
    "password": "Secret",
    "server": "mongo-db",
}

connector = "mongodb://{}:{}@{}".format(config["username"], config["password"], config["server"])
client = pymongo.MongoClient(connector)
db = client["avito"]

@app.route("/avito-api/GetItemPhone/<idnum>", methods=['GET'])
def GetItemPhone(idnum):
    
    phones = []

    try:
        cur = db.phones.find({"$where": "this.item_id == '"+idnum+"'" })
        for i in cur:
            phones.append({ key: i[key] for key in ['item_id','phone'] })
    except:
        pass

    if phones :
        return jsonify({'phones':phones})
    else:
        return jsonify({'message':'Id not found'}), 404


@app.route("/avito-api/GetItem/<idnum>", methods=['GET'])
def GetItem(idnum):
    
    items = [] 

    try:
        cur = db.items.find({"$where": "this.item_id == '"+idnum+"'" })
        for i in cur:
            items.append({ key: i[key] for key in ['item_id','title','image_path','descr','user_id','username'] })
    except:
        pass

    if items :
        return jsonify({'items':items})
    else:
        return jsonify({'message':'Id not found'}), 404

@app.route("/avito-api/GetUser/<idnum>", methods=['GET'])
def GetUser(idnum):
    
    users = [] 

    try:
        cur = db.users.find({"$where": "this.user_id == '"+idnum+"'" })
        for i in cur:
            users.append({ key: i[key] for key in ['user_id','username','avatar_path','descr'] })
    except:
        pass

    if users :
        return jsonify({'users':users})
    else:
        return jsonify({'message':'Id not found'}), 404

