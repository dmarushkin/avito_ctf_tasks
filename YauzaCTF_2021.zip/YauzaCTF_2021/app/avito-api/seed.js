db.phones.drop();
db.phones.insertMany([
    {
        "item_id": "0000faed",
        "phone": "+79997893412"
    }
]);

db.items.drop();
db.items.insertMany([
    {
        "item_id": "0000faed",
        "title": "Test item for new API",
        "image_path": "img/test.jpg",
        "descr": "Do not buy, it is test, realy test!",
        "user_id": "6665fe3cbe5cce08dfa567dbbbc2059949a9f946",
        "username": "test"
    }
]);

db.users.drop();
db.users.insertMany([
    {
        "user_id": "c1771c849f77c3269c64134c3a0b808e66eb5a20",
        "username": "Sheldon Cooper",
        "avatar_path": "img/avatar_admin.jpg",
        "descr": "Welcome to Fun with Flags! If you are not blind, check new one in my flag field! ",
        "flag": "{4v1t0_4nt1b0t_t3st}"
    },
    {
        "user_id": "6665fe3cbe5cce08dfa567dbbbc2059949a9f946",
        "username": "test",
        "avatar_path": "img/avatar_test.jpg",
        "descr": "Only boring test user here, look harder!"
    }
]);